﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebTestAPI.DTOs;
using WebTestAPI.ModelFromDB;
using WebTestAPI.Services;

namespace WebTestAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly CSDL_SmookingPlatFrom _context;
        private readonly TokenService _tokenService;

        public LoginController(CSDL_SmookingPlatFrom context, TokenService tokenService)
        {
            _context = context;
            _tokenService = tokenService;
        }

        [HttpPost]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            var user = await _context.Users.Include(u => u.Role)
                .FirstOrDefaultAsync(u => u.Email == request.Email);

            if (user == null || user.Password != request.Password)
                return Unauthorized(new { message = "Sai tài khoản hoặc mật khẩu" });

            var token = _tokenService.CreateToken(user);

            return Ok(new
            {
                token = token,
                message = "Đăng nhập thành công!",
                role = user.Role?.RoleName ?? "Member",
                fullName = user.FullName
            });
        }
    }
}